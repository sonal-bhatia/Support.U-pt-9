//
//  ToDo.swift
//  Support.U
//
//  Created by Laura Pena on 8/12/20.
//  Copyright © 2020 Sonal Bhatia. All rights reserved.
//

import UIKit

class ToDoClass {
    var description = ""
    var important = false
}
